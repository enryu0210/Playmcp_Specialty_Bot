import pandas as pd

DATA_FILE = 'coffee_clean.csv'

# 주요 커피 생산국 리스트
MAJOR_COUNTRIES = [
    'Ethiopia', 'Kenya', 'Colombia', 'Brazil', 'Panama', 'Guatemala', 
    'Costa Rica', 'Indonesia', 'Honduras', 'El Salvador', 'Peru', 'Rwanda',
    'Mexico', 'Uganda', 'Tanzania', 'Nicaragua', 'Yemen', 'Sumatra', 'India', 'Vietnam'
]

def load_data():
    try:
        df = pd.read_csv(DATA_FILE)
        df['desc_1'] = df['desc_1'].fillna('').astype(str)
        # 국가명 추출
        def extract_country(origin_text):
            if not isinstance(origin_text, str): return "Other"
            for country in MAJOR_COUNTRIES:
                if country.lower() in origin_text.lower():
                    return country
            return "Other"
        df['country'] = df['origin'].apply(extract_country)
        return df
    except FileNotFoundError:
        return None

def get_coffee_recommendations(preference: str):
    df = load_data()
    if df is None:
        return "Error: 데이터 파일을 찾을 수 없습니다."

    # --- 1. 취향 분석 및 필터링 기준 설정 ---
    
    # (A) 산미(Acidic) 요청
    if any(word in preference for word in ["산미", "과일", "신맛", "상큼", "꽃", "화사"]):
        target_type = 'acidic'
        # 1. Acid 점수 기준: 9점 이상 (High Acid)
        df = df[df['acid'] >= 9.0].copy()
        
        # 2. 반대 노트(Opposite Note) 제외 키워드: 흙내, 텁텁함, 탄맛
        exclude_keywords = ['earthy', 'tobacco', 'smoke', 'ash', 'leather', 'musty', 'rubber', 'medicinal']
        
        priority_countries = ['Ethiopia', 'Panama', 'Kenya'] 
        flavor_desc = "화사한 산미와 과일향 (High Acid, No Earthy)"

    # (B) 고소(Nutty) 요청
    elif any(word in preference for word in ["고소", "견과", "구수", "묵직", "초콜릿", "바디", "쓴맛"]):
        target_type = 'nutty'
        # 1. Acid 점수 기준: 8점 이하 (Low Acid)
        df = df[df['acid'] <= 8.0].copy()
        
        # 2. 반대 노트(Opposite Note) 제외 키워드: 강한 산미 표현
        # 'fruit' 자체를 빼면 데이터가 거의 없으므로 'bright', 'tart' 등 산미의 '성질'을 나타내는 단어 위주로 제외
        exclude_keywords = ['bright', 'tart', 'citrus', 'lemon', 'lime', 'grapefruit', 'wine', 'sour', 'vibrant', 'acidy', 'vinegar']
        
        priority_countries = ['Brazil', 'Colombia', 'Guatemala', 'Indonesia', 'India']
        flavor_desc = "고소하고 묵직한 바디감 (Low Acid, No Citrus/Tart)"
        
    else:
        return "죄송합니다. '고소한' 또는 '산미있는' 맛으로 질문해 주세요."

    # --- 2. 텍스트 기반 반대 성향 제외 (Negative Filtering) ---
    # desc_1(설명)에 제외 키워드가 하나라도 있으면 탈락
    exclude_pattern = '|'.join(exclude_keywords)
    # contains( ... ) 가 True인 행을 제외(~)
    filtered_df = df[~df['desc_1'].str.contains(exclude_pattern, case=False, na=False)].copy()

    if filtered_df.empty:
        return f"조건에 맞는 커피를 찾을 수 없습니다. (필터링 조건이 너무 엄격할 수 있습니다)"

    # --- 3. 국가별 그룹화 및 선정 ---
    available_countries = filtered_df['country'].unique()
    selected_countries = []
    
    # (1) 우선순위 국가 먼저 확보
    for p_country in priority_countries:
        if p_country in available_countries:
            selected_countries.append(p_country)
            
    # (2) 부족하면 평점 높은 다른 국가 추가 (총 3개까지)
    if len(selected_countries) < 3:
        country_ratings = filtered_df.groupby('country')['rating'].mean().sort_values(ascending=False)
        for country in country_ratings.index:
            if country not in selected_countries and country != "Other":
                selected_countries.append(country)
                if len(selected_countries) >= 3:
                    break
    
    # --- 4. 최종 결과 구성 ---
    results = {
        "flavor_desc": flavor_desc,
        "countries": []
    }

    for country in selected_countries:
        country_coffees = filtered_df[filtered_df['country'] == country]
        # 점수 높은 순 -> 상위 2개
        top_coffees = country_coffees.sort_values(by='rating', ascending=False).head(2)
        
        coffee_list = []
        for _, row in top_coffees.iterrows():
            coffee_list.append({
                "name": row['name'],
                "roaster": row['roaster'],
                "rating": row['rating'],
                "desc": row['desc_1']
            })
            
        results["countries"].append({
            "country_name": country,
            "coffees": coffee_list
        })

    return results