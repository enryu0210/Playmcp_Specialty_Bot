from mcp.server.fastmcp import FastMCP
from coffee_tools import get_coffee_recommendations

mcp = FastMCP("Coffee Recommender")

@mcp.tool()
def recommend_coffee(preference: str) -> str:
    """
    사용자의 취향(고소/산미)을 입력받아
    산미 수치와 반대 성향 노트 제외 로직이 적용된 국가별 추천 가이드를 제공합니다.
    """
    result_data = get_coffee_recommendations(preference)
    
    if isinstance(result_data, str):
        return result_data
        
    flavor_title = result_data['flavor_desc']
    
    output = [f"### ☕ {preference} 취향 맞춤 커피 가이드"]
    output.append(f"_{flavor_title} 위주로 엄선했습니다._\n")
    
    for country_info in result_data['countries']:
        country_name = country_info['country_name']
        
        flag = "🏳️"
        if country_name == "Ethiopia": flag = "🇪🇹"
        elif country_name == "Kenya": flag = "🇰🇪"
        elif country_name == "Colombia": flag = "🇨🇴"
        elif country_name == "Brazil": flag = "🇧🇷"
        elif country_name == "Panama": flag = "🇵🇦"
        elif country_name == "Guatemala": flag = "🇬🇹"
        elif country_name == "Indonesia": flag = "🇮🇩"
        
        output.append(f"#### {flag} {country_name}")
        
        for coffee in country_info['coffees']:
            # 첫 문장만 깔끔하게 표시
            short_desc = coffee['desc'].split('.')[0] + "."
            output.append(f"- **{coffee['name']}** ({coffee['rating']}점)")
            output.append(f"  └ 📝 {short_desc}")
            
        output.append("") 
        
    return "\n".join(output)

if __name__ == "__main__":
    mcp.run()